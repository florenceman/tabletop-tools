#TODO
- add way to do rest of letters
- add way to determine custom frequency of letters by previous letter